/**
* Global Variables
*/
var BASE_CONTEXT_PATH = $('meta[name=context-path').attr("content");