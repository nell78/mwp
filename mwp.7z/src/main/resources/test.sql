CREATE TABLE test
(
	id integer NOT NULL,
	content varchar(255),
	primary key(id)
);

INSERT INTO test (id, content) values (111,'hahahaha');
INSERT INTO test (id, content) values (222,'hohohoho');
INSERT INTO test (id, content) values (333,'hihihihi');